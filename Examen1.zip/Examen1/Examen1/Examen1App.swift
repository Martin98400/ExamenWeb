//
//  Examen1App.swift
//  Examen1
//
//  Created by CCDM20 on 14/11/22.
//

import SwiftUI
import CoreData

@main
struct Examen1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView(CoreDM:CoreDataManager())
        }
    }
}
